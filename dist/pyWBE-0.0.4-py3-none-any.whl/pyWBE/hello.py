def hello_world():
    print("Hello World! This is the pyWBE Library")
    return None
